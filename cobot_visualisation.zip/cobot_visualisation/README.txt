Install moveit_visual_tools package:
	Ubuntu Debian:
	sudo apt-get install ros-kinetic-moveit-visual-tools

Before first run do catkin_make in your catkin workspace!

For operation:
	rosrun cobot_visualisation visualisation_node
	rosrun covot_visualisation distance_node

For visualisation testing:
	roslaunch cobot_visualisation ur5_demo.launch
	rosrun cobot_visualisation visualisation_node
	rosrun cobot_visualisation distance_node
	rosrun cobot_visualisation object_publisher_node
